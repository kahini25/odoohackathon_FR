const mongoose = require('mongoose');

const answerSchema = new mongoose.Schema({
  content: String,
  author: String,
  createdAt: { type: Date, default: Date.now },
  votes: { type: Number, default: 0 },
  accepted: { type: Boolean, default: false }
});

const questionSchema = new mongoose.Schema({
  title: String,
  body: String,
  author: String,
  createdAt: { type: Date, default: Date.now },
  votes: { type: Number, default: 0 },
  tags: [String],
  answers: [answerSchema]  // ✅ Embedded answers array
});

module.exports = mongoose.model('Question', questionSchema);
